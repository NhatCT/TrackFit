package com.ntn.services.impl;

import com.cloudinary.Cloudinary;
import com.cloudinary.utils.ObjectUtils;
import com.ntn.pojo.User;
import com.ntn.repositories.UserRepository;
import com.ntn.services.UserService;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service("userDetailsService")
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private Cloudinary cloudinary;

    @Override
    public User getUserByUsername(String username) {
        return this.userRepo.getUserByUsername(username);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = this.getUserByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException("Invalid username!");
        }

        Set<GrantedAuthority> authorities = new HashSet<>();
        authorities.add(new SimpleGrantedAuthority(user.getRole()));

        return new org.springframework.security.core.userdetails.User(
                user.getUsername(), user.getPassword(), authorities);
    }

    @Override
    public User register(Map<String, String> params, MultipartFile avatar) {
        User user = new User();
        user.setUsername(params.get("username"));
        user.setPassword(this.passwordEncoder.encode(params.get("password")));
        user.setEmail(params.get("email"));
        user.setFirstName(params.get("firstName"));
        user.setLastName(params.get("lastName"));
        user.setRole("ROLE_USER");
        user.setCreatedAt(new Date());

        if (avatar != null && !avatar.isEmpty()) {
            try {
                Map<String, Object> res = cloudinary.uploader().upload(avatar.getBytes(),
                        ObjectUtils.asMap("resource_type", "auto"));
                user.setAvatarUrl(res.get("secure_url").toString());
            } catch (IOException ex) {
                Logger.getLogger(UserServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return this.userRepo.addUser(user);
    }

    @Override
    public boolean updateHealthMetrics(String username, Map<String, String> healthMetrics) {
        User user = this.getUserByUsername(username);
        if (user != null) {
            try {
                if (healthMetrics.containsKey("gender")) {
                    user.setGender(healthMetrics.get("gender"));
                }
                if (healthMetrics.containsKey("birthDate")) {
                    try {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                        user.setBirthDate(sdf.parse(healthMetrics.get("birthDate")));
                    } catch (Exception e) {
                        Logger.getLogger(UserServiceImpl.class.getName())
                                .log(Level.WARNING, "Invalid birthDate format", e);
                    }
                }
                user.setUpdatedAt(new Date());
                this.userRepo.updateUser(user);
                return true;
            } catch (Exception e) {
                Logger.getLogger(UserServiceImpl.class.getName())
                        .log(Level.SEVERE, "Error updating health metrics", e);
            }
        }
        return false;
    }

    @Override
    public boolean authenticate(String username, String password) {
        return this.userRepo.authenticate(username, password);
    }

    @Override
    public void changePassword(String username, String oldPassword, String newPassword) {
        User user = this.userRepo.getUserByUsername(username);

        if (!this.passwordEncoder.matches(oldPassword, user.getPassword())) {
            throw new RuntimeException("Mật khẩu cũ không đúng!");
        }

        user.setPassword(this.passwordEncoder.encode(newPassword));
        this.userRepo.updateUser(user);
    }

    @Override
    public void updateAvatar(String username, MultipartFile avatar) {
        User user = this.userRepo.getUserByUsername(username);
        if (avatar != null && !avatar.isEmpty()) {
            try {
                Map<String, Object> res = cloudinary.uploader().upload(avatar.getBytes(),
                        ObjectUtils.asMap("resource_type", "auto"));
                user.setAvatarUrl(res.get("secure_url").toString());
            } catch (IOException ex) {
                Logger.getLogger(UserServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.userRepo.updateUser(user);
        }
    }

    @Override
    public User getUserWithHealthInfo(String username) {
        return this.userRepo.getUserByUsername(username);
    }
}
