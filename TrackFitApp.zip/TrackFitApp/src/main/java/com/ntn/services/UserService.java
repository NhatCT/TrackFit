package com.ntn.services;

import com.ntn.pojo.User;
import java.util.Map;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.multipart.MultipartFile;

public interface UserService extends UserDetailsService {

    User getUserByUsername(String username);

    User register(Map<String, String> params, MultipartFile avatar);

    boolean updateHealthMetrics(String username, Map<String, String> healthMetrics);

    boolean authenticate(String username, String password);

    void changePassword(String username, String oldPassword, String newPassword);

    void updateAvatar(String username, MultipartFile avatar);

    User getUserWithHealthInfo(String username);
}
