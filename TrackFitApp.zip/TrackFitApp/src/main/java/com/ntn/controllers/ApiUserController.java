package com.ntn.controllers;

import com.ntn.pojo.User;
import com.ntn.services.UserService;
import com.ntn.utils.JwtUtils;
import java.security.Principal;
import java.util.Collections;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class ApiUserController {

    @Autowired
    private UserService userDetailsService;

    // Đăng ký
    @PostMapping(path = "/register",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<User> register(@RequestParam Map<String, String> params,
                                         @RequestParam(value = "avatar", required = false) MultipartFile avatar) {
        return new ResponseEntity<>(this.userDetailsService.register(params, avatar), HttpStatus.CREATED);
    }

    // Đăng nhập
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User u) {
        if (this.userDetailsService.authenticate(u.getUsername(), u.getPassword())) {
            try {
                String token = JwtUtils.generateToken(u.getUsername());
                return ResponseEntity.ok(Collections.singletonMap("token", token));
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Lỗi khi tạo JWT");
            }
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Sai thông tin đăng nhập");
    }

    // Lấy profile người dùng hiện tại
    @GetMapping("/secure/profile")
    public ResponseEntity<User> getProfile(Principal principal) {
        return new ResponseEntity<>(this.userDetailsService.getUserByUsername(principal.getName()), HttpStatus.OK);
    }

    // Đổi mật khẩu
    @PostMapping("/secure/password")
    public ResponseEntity<?> changePassword(@RequestBody Map<String, String> data) {
        try {
            String username = SecurityContextHolder.getContext().getAuthentication().getName();
            String oldPassword = data.get("oldPassword");
            String newPassword = data.get("newPassword");
            this.userDetailsService.changePassword(username, oldPassword, newPassword);
            return ResponseEntity.ok(Collections.singletonMap("message", "Password changed successfully"));
        } catch (RuntimeException ex) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Collections.singletonMap("message", ex.getMessage()));
        }
    }

    // Cập nhật avatar
    @PostMapping("/secure/avatar")
    public ResponseEntity<User> changeAvatar(@RequestParam("avatar") MultipartFile avatar) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        this.userDetailsService.updateAvatar(username, avatar);
        return new ResponseEntity<>(this.userDetailsService.getUserByUsername(username), HttpStatus.OK);
    }

    // Lấy profile của username khác
    @GetMapping("/secure/profile/{username}")
    public ResponseEntity<User> getProfileByUsername(@PathVariable String username) {
        return new ResponseEntity<>(this.userDetailsService.getUserByUsername(username), HttpStatus.OK);
    }
}
